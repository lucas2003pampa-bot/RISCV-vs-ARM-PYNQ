// firmware.c - Buscador de Primos
// Optimizamos el límite a 2000 para que no tardes una eternidad esperando
#define LIMITE 2000 

// Memoria compartida
volatile int *SHARED_RESULT = (int *) 0x00001FF0; // Aquí guardamos cuantos encontramos
volatile int *SHARED_FLAG   = (int *) 0x00001FF8; // Bandera de fin

// Función auxiliar (El compilador insertará librerías de división por software aquí)
int es_primo(int n) {
    if (n <= 1) return 0;
    // OJO: i*i requiere multiplicación. n%i requiere división.
    // Esto va a hacer sufrir mucho al RISC-V rv32i.
    for (int i = 2; i * i <= n; i++) {
        if (n % i == 0) return 0;
    }
    return 1;
}

int main() {
    int contador = 0;
    
    // 1. Limpiar bandera
    *SHARED_FLAG = 0;

    // 2. Bucle de búsqueda
    for (int i = 0; i <= LIMITE; i++) {
        if (es_primo(i)) {
            contador++;
        }
    }

    // 3. Escribir resultado
    *SHARED_RESULT = contador;
    
    // 4. Avisar que hemos terminado
    *SHARED_FLAG = 1;

    while(1);
    return 0;
}