// simple.c - Solo para ver si el procesador respira
volatile int *FLAG_ADDR = (int *) 0x00001FF8;

int main() {
    // Escribir 1 inmediatamente. Sin sumas, sin decimales, sin nada.
    *FLAG_ADDR = 1; 
    
    while(1); // Quedarse quieto
    return 0;
}