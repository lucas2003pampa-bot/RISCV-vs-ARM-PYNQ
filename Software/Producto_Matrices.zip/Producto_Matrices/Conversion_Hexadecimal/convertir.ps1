$ficheroEntrada = "C:\Proyectos\Primos\firmware.bin"
$ficheroSalida  = "C:\Proyectos\Primos\firmware.h"

$bytes = [System.IO.File]::ReadAllBytes($ficheroEntrada)
$sb = New-Object System.Text.StringBuilder
$null = $sb.Append("const unsigned char riscv_firmware[] = {`r`n")

$counter = 0
foreach ($b in $bytes) {
    $hex = "0x{0:X2}, " -f $b
    $null = $sb.Append($hex)
    $counter++
    if ($counter % 16 -eq 0) {
        $null = $sb.Append("`r`n")
    }
}

$null = $sb.Append("`r`n};")
[System.IO.File]::WriteAllText($ficheroSalida, $sb.ToString())

Write-Host "LISTO. Archivo creado correctamente."