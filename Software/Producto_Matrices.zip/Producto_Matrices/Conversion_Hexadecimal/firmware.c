// firmware.c - Multiplicación de Matrices Enteras
// TAMAÑO ADAPTADO A 8KB BRAM
#define N 16 

// Punteros para comunicar el fin y un dato de control
volatile int *SHARED_FLAG  = (int *) 0x00001FF8;
volatile int *SHARED_CHECK = (int *) 0x00001FF0; // Para guardar C[1][1] y verificar

// Matrices globales (se guardan en la BRAM)
int A[N][N];
int B[N][N];
int C[N][N];

int main() {
    int i, j, k;
    
    // 0. Limpiar bandera
    *SHARED_FLAG = 0;

    // 1. Inicializar matrices
    for(i=0; i<N; i++) {
        for(j=0; j<N; j++) {
            A[i][j] = i + 1;
            B[i][j] = i + j;
            C[i][j] = 0;
        }
    }

    // 2. Multiplicación de Matrices (Núcleo O(n^3))
    for(i=0; i<N; i++) {
        for(j=0; j<N; j++) {
            int suma_temp = 0;
            for(k=0; k<N; k++) {
                suma_temp += A[i][k] * B[k][j];
            }
            C[i][j] = suma_temp;
        }
    }

    // 3. Escribir resultado de control (para ver si calculó bien)
    *SHARED_CHECK = C[1][1];

    // 4. Levantar bandera de fin
    *SHARED_FLAG = 1;

    while(1);
    return 0;
}