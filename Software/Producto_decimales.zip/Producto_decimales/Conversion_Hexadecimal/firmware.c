#define NUM_STEPS 2000 

volatile float *RESULT_ADDR = (float *) 0x00001FF0; // Cambiado a float
volatile int   *FLAG_ADDR   = (int *)   0x00001FF8;

int main() {
    float step, x, sum = 0.0f;
    int i;
    
    // 1. Limpiar bandera
    *FLAG_ADDR = 0;

    // 2. Calculo con FLOAT (Menos peso)
    step = 1.0f / (float) NUM_STEPS;

    for (i = 0; i < NUM_STEPS; i++) {
        x = (i + 0.5f) * step;
        sum = sum + 4.0f / (1.0f + x * x);
    }

    float pi = step * sum;

    // 3. Escribir resultados
    *RESULT_ADDR = pi;
    *FLAG_ADDR = 1; // ¡FIN!

    while(1);
    return 0;
}